# set DATABASE_URL=postgresql://postgres:9mobile@localhost:5432/lecture1

import os
os.putenv("DATABASE_URL", "postgresql://postgres:9mobile@localhost:5432/lecture1")