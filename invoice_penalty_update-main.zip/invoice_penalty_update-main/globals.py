# def gf():
# 	global f
# 	f ='blipp'
# 	return f
